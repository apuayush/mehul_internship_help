var phase=[];
var datatype=[];
var datanature=[];
var stratified=[];
var no_of_stratas=[];
var stratanumber=[];
var strata_name=[];
var strata_criteria=[];
var numberarr=[];
function addFields(){
        var number = document.getElementById("insert").value;
        numberarr.push(number);
        console.log(numberarr)
        var container = document.getElementById("container");
        //var subcontainer= document.getElementById("sub");
        while (container.hasChildNodes()){
      	container.removeChild(container.lastChild);
    }
    for (i=0;i<number;i++){
        container.appendChild(document.createTextNode("PHASE "+(i+1)+" DETAILS"));
        container.appendChild(document.createElement("br"));
        container.appendChild(document.createElement("br"));
        container.appendChild(document.createTextNode("\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0"));
        container.appendChild(document.createTextNode("Phase  " + (i+1)+" Name \u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0: "));
        var input = document.createElement("input");
        input.type = "text";
        input.setAttribute("id","phase"+i);
        container.appendChild(input);
        container.appendChild(document.createElement("br"));
        container.appendChild(document.createElement("br"));

        container.appendChild(document.createTextNode("Data Type of Phase  " + (i+1)+"   : "));
        var select_datatype =document.createElement("select");
    	container.appendChild(select_datatype);
    	select_datatype.setAttribute("id","datatype"+i);
    	var option= document.createElement("option");
    	option.text="";
    	select_datatype.add(option);
    	var option1 = document.createElement("option");
    	option1.text = "Ratio";
    	select_datatype.add(option1);
    	var option2= document.createElement("option");
    	option2.text="Ordinal";
    	select_datatype.add(option2);
    	var option3= document.createElement("option");
    	option3.text="Nominal";
    	select_datatype.add(option3);
    	container.appendChild(document.createElement("br"));
    	container.appendChild(document.createElement("br"));

    	container.appendChild(document.createTextNode("Nature of Phase  " + (i+1) +"\u00a0\u00a0\u00a0\u00a0\u00a0"+ "   : "));
        var select_nature =document.createElement("select");
    	container.appendChild(select_nature);
    	select_nature.setAttribute("id","datanature"+i);
    	var option= document.createElement("option");
    	option.text="";
    	select_nature.add(option);
    	var option1= document.createElement("option");
    	option1.text="Sequential";
    	select_nature.add(option1);
    	var option2= document.createElement("option");
    	option2.text="Diverging";
    	select_nature.add(option2);
    	var option3= document.createElement("option");
    	option3.text="Qualitative";
    	select_nature.add(option3)
    	container.appendChild(document.createElement("br"));
    	container.appendChild(document.createElement("br"));

    	container.appendChild(document.createTextNode("Can Data be Stratified : "));
        var select_stratify =document.createElement("select");
    	container.appendChild(select_stratify);
    	select_stratify.setAttribute("id","stratified"+i);
   		var option = document.createElement("option");
    	option.text="";
    	select_stratify.add(option);
    	var option1= document.createElement("option");
    	option1.text="Yes";
    	select_stratify.add(option1);
    	var option2= document.createElement("option");
    	option2.text="No";
    	select_stratify.add(option2);
    	container.appendChild(document.createElement("br"));
    	container.appendChild(document.createElement("br"));
        container.appendChild(document.createTextNode("\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0"))
    	container.appendChild(document.createTextNode("Number of Stratas \u00a0\u00a0\u00a0\u00a0\u00a0: "));
        var no_of_stratas =document.createElement("input");
        no_of_stratas.type="number";
        no_of_stratas.setAttribute("id","no_of_stratas"+i);
    	container.appendChild(no_of_stratas);
    	container.appendChild(document.createElement("br"));
    	container.appendChild(document.createElement("br"));


    	/*var strata_button=document.createElement("input");
    	strata_button.setAttribute("type","button");
    	strata_button.setAttribute("value","Fill Strata Details");
    	strata_button.setAttribute("id","strata_button"+i);
    	//strata_button.setAttribute("onclick",StrataDetails());
    	container.appendChild(strata_button);
    	container.appendChild(document.createElement("br"));
    	container.appendChild(document.createElement("br"));
    	//numberarr.push(no_of_stratas.value);*/
    	//console.log(numberarr);
    	var hr2=document.createElement("hr");
        hr2.width="500px";
        container.appendChild(hr2);
        container.appendChild(document.createElement("br"));
   	}
}
//console.log(stratanumber);

	
	//console.log(stratanumber);


	/*document.getElementById("no_of_stratas"+i).addEventListener("onchange",function(){
    	for(j=0;j<5;j++){
    		subcontainer.appendChild(document.createTextNode("Strata Name :"));
    		var div=document.createElement("div");
    		div.appendChild(document.createElement("br"));
    		var strata_name= document.createElement("input");
    		strata_name.type="text";
    		strata_name.setAttribute("id","strata_name"+j);
        	subcontainer.appendChild(strata_name);
        	subcontainer.appendChild(document.createElement("br"));*/
       
//console.log(numberarr);
var phase_copy=[];
function StrataDetails(){	
	for(j=0;j<parseInt(numberarr[0]);j++){
        phase_copy.push(document.getElementById("phase"+j).value);
		container.appendChild(document.createTextNode("Enter Strata Details For Phase "+ phase_copy[j]+ " "));
		container.appendChild(document.createElement("br"));
		container.appendChild(document.createElement("br"));
		stratanumber.push(document.getElementById("no_of_stratas"+j).value);
		for(k=0;k<(document.getElementById("no_of_stratas"+j).value);k++){
			var strata_name=document.createElement("input");
			var strata_criteria=document.createElement("input");
			strata_criteria.type="text";
			strata_name.type="text";
			strata_name.setAttribute("placeHolder","Strata Name");
			strata_criteria.setAttribute("placeHolder","Strata Criteria");
			strata_name.setAttribute("id","strata_name"+j+k);
			strata_criteria.setAttribute("id","strata_criteria"+j+k);
			container.appendChild(strata_name);
			container.appendChild(strata_criteria);
			container.appendChild(document.createElement("br"));
			//console.log(strata_name.id);
			//container.appendChild(document.createElement("br"));
		}
		container.appendChild(document.createElement("br"));
	}
	//console.log(sum);
}

var phasedetails =[];
var stratadetails =[];
var strata_details=[];
function GetDetails(){
    for(j=0;j<parseInt(numberarr[0]);j++){
    	phase.push(document.getElementById("phase"+j).value);
    	datatype.push(document.getElementById("datatype"+j).value);
    	datanature.push(document.getElementById("datanature"+j).value);
    	stratified.push(document.getElementById("stratified"+j).value);
    	no_of_stratas.push(document.getElementById("no_of_stratas"+j).value);
    }
    for(l=0;l<stratanumber.length;l++){
    	for(k=0;k<stratanumber[l];k++){
    		stratadetails.push([document.getElementById("strata_name"+l+k).value,document.getElementById("strata_criteria"+l+k).value]);
    		//strata_criteria.push(document.getElementById("strata_criteria"+l+k).value);
    	}
    }
    var nos=[];
    for(i=0;i<no_of_stratas.length;i++){
    	nos.push(parseInt(no_of_stratas[i]));
    }
    phasedetails.push(phase,datatype,datanature,stratified,no_of_stratas);
    //stratadetails.push(strata_name,strata_criteria);
    phasedetails[0].unshift("0");
    console.log(phasedetails);
    console.log(stratadetails);
    for(j=0;j<stratanumber.length;j++){
    	strata_details.push(stratadetails.slice(0,stratanumber[j]));
    	stratadetails=stratadetails.slice(stratanumber[j],stratadetails.length+1);
    }
    console.log(strata_details);
    var new_arr=[];
    for(i=0;i<stratanumber.length;i++){
   		for(j=0;j<stratanumber[i];j++){
   			for(k=0;k<strata_details.length;k++){
   				new_arr.push(strata_details[i][j]);
   			}
   		}
   	}
   	Array.prototype.max = function() {
      return Math.max.apply(null, this);
    };
    var x=nos.max();
    var strata_list=[];
    for(i=0;i<x;i++){
    	var strata_sublist=[];
    	for(j=0;j<strata_details.length;j++){
    		strata_sublist.push(strata_details[j][i]);
    	}
    	strata_list.push(strata_sublist);
    }
    console.log(strata_list);
    var newArr=[];
    for(i=0;i<strata_list.length;i++){
    	var newArr2=[];
    	for(j=0;j<strata_list[i].length;j++){
    		newArr2=newArr2.concat(strata_list[i][j]);
    	}
    	newArr.push(newArr2);
    }
    console.log(newArr);
    //newArr[0].unshift("0");
    for(i=0;i<newArr.length;i++){
    	for(j=0;j<newArr[i].length;j++){
    		if(typeof(newArr[i][j])=='undefined'){
    			newArr[i].splice(j+1,0,'');
    		}
    	}
    }
    console.log(newArr.length);
    var headers=[];
    for(i=0;i<strata_details.length;i++){
    	headers.push('Strata','Criteria');
    }
    headers.unshift("");
    newArr.unshift(headers);

    var csvContent = "data:text/csv;charset=utf-8";
    phasedetails.forEach(function(infoArray,index){
        dataString=infoArray.join(",");
        csvContent += index < phasedetails.length ? dataString + "\n" : dataString;
    });
    var encodedUri = encodeURI(csvContent);
    var link=document.createElement("a");
    link.setAttribute("href",encodedUri);
    link.setAttribute("download","PhaseDetails.csv");
    document.body.appendChild(link);
    link.click();

    var csvContent2 = "data:text/csv;charset=utf-8";
    newArr.forEach(function(infoArray,index){
        dataString2=infoArray.join(",");
        csvContent2 += index < newArr.length ? dataString2 + "\n" : dataString2;
    });
    var encodedUri2 = encodeURI(csvContent2);
    var link2=document.createElement("a");
    link2.setAttribute("href",encodedUri2);
    link2.setAttribute("download","StrataDetails.csv");
    document.body.appendChild(link2);
    link2.click();

    var phaseforsampledata=[];
    phaseforsampledata.push(phase);
    phaseforsampledata[0].shift();
    phaseforsampledata[0].unshift("Primary Key");
    phaseforsampledata[0].unshift(" ");
    console.log(phaseforsampledata);
    var csvContent3 = "data:text/csv;charset=utf-8";
    phaseforsampledata.forEach(function(infoArray,index){
        dataString3=infoArray.join(",");
        csvContent3 += index < phaseforsampledata.length ? dataString3 + "\n" : dataString3;
    });
    var encodedUri3 = encodeURI(csvContent3);
    var link3=document.createElement("a");
    link3.setAttribute("href",encodedUri3);
    link3.setAttribute("download","SampleData.csv");
    document.body.appendChild(link3);
    link3.click();

}